using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ActionScript : ScriptableObject
{
    public string keyword;

    public abstract void RespondToInput(GameController controller, string verb);

}
